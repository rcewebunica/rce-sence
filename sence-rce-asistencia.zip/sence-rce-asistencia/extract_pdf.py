import pypdf

reader = pypdf.PdfReader('integracion_registro_asistencia_sence_v1.1.5_0.pdf')
print(f'Total paginas: {len(reader.pages)}')
print('=' * 80)

for i, page in enumerate(reader.pages):
    text = page.extract_text()
    if text and text.strip():
        print(f'\n===== PAGINA {i+1} =====')
        print(text)
