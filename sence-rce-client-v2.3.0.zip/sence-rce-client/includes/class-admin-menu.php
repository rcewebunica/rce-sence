<?php
/**
 * Menú y paneles administrativos de WordPress para SENCE RCE Cloud
 */
class Sence_RCE_Admin_Menu {

    private $api;

    public function __construct( $api_client ) {
        $this->api = $api_client;
    }

    public function add_menu() {
        add_menu_page(
            'SENCE RCE',
            'SENCE RCE ☁️',
            'manage_options',
            'sence-rce',
            array( $this, 'render_dashboard' ),
            'dashicons-cloud-saved',
            56
        );

        add_submenu_page(
            'sence-rce',
            'Panel de Control',
            'Panel',
            'manage_options',
            'sence-rce',
            array( $this, 'render_dashboard' )
        );

        add_submenu_page(
            'sence-rce',
            'Cursos SENCE',
            'Cursos SENCE',
            'manage_options',
            'sence-rce-courses',
            array( $this, 'render_courses' )
        );

        add_submenu_page(
            'sence-rce',
            'Sesiones y Asistencias',
            'Sesiones',
            'manage_options',
            'sence-rce-sessions',
            array( $this, 'render_sessions' )
        );

        add_submenu_page(
            'sence-rce',
            'Configuración',
            'Configuración',
            'manage_options',
            'sence-rce-settings',
            array( $this, 'render_settings' )
        );
    }

    public function enqueue_admin_assets( $hook ) {
        if ( strpos( $hook, 'sence-rce' ) === false ) {
            return;
        }

        wp_enqueue_style(
            'sence-rce-admin-css',
            SENCE_RCE_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            SENCE_RCE_VERSION
        );

        wp_enqueue_script(
            'sence-rce-admin-js',
            SENCE_RCE_PLUGIN_URL . 'assets/js/admin.js',
            array( 'jquery' ),
            SENCE_RCE_VERSION,
            true
        );

        wp_localize_script( 'sence-rce-admin-js', 'senceRceAdmin', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'sence_rce_admin_nonce' )
        ) );
    }

    public function render_dashboard() {
        $stats = $this->api->get_stats();
        if ( is_wp_error( $stats ) || ! is_array( $stats ) ) {
            $stats = false;
        }

        $conn = $this->api->test_connection();
        if ( is_wp_error( $conn ) || ! is_array( $conn ) ) {
            $conn = array( 'success' => false, 'message' => 'No conectado' );
        }

        $opts = get_option( 'sence_rce_cloud_options', array() );
        ?>
        <div class="wrap sence-rce-wrap">
            <h1>🇨🇱 SENCE RCE — Panel de Control SaaS</h1>

            <div class="sence-rce-connection-bar <?php echo ! empty( $conn['success'] ) ? 'connected' : 'disconnected'; ?>">
                <span class="status-indicator"></span>
                <span><strong>Estado Servidor Central:</strong> <?php echo esc_html( $conn['message'] ?? 'No conectado' ); ?></span>
                <?php if ( ! empty( $opts['test_env'] ) ) : ?>
                    <span class="sence-badge warning" style="margin-left:auto;">MODO DE PRUEBA ACTIVO</span>
                <?php else : ?>
                    <span class="sence-badge success" style="margin-left:auto;">PRODUCCIÓN SENCE</span>
                <?php endif; ?>
            </div>

            <?php if ( ! empty( $stats ) ) : ?>
            <div class="sence-rce-stats-grid">
                <div class="sence-rce-stat-card">
                    <div class="stat-num"><?php echo esc_html( $stats['total_sessions'] ?? 0 ); ?></div>
                    <div class="stat-label">Total Asistencias Históricas</div>
                </div>
                <div class="sence-rce-stat-card">
                    <div class="stat-num color-success"><?php echo esc_html( $stats['active_sessions'] ?? 0 ); ?></div>
                    <div class="stat-label">Sesiones Activas Ahora</div>
                </div>
                <div class="sence-rce-stat-card">
                    <div class="stat-num color-primary"><?php echo esc_html( $stats['sessions_this_month'] ?? 0 ); ?></div>
                    <div class="stat-label">Asistencias Este Mes</div>
                </div>
                <div class="sence-rce-stat-card">
                    <div class="stat-num"><?php echo esc_html( $stats['total_courses'] ?? 0 ); ?></div>
                    <div class="stat-label">Cursos Sincronizados</div>
                </div>
            </div>

            <?php else : ?>
            <div class="sence-rce-card">
                <p>⚠️ No se pudieron obtener estadísticas del servidor central. Verifique que la URL y la API Key estén correctamente ingresadas en <a href="<?php echo admin_url( 'admin.php?page=sence-rce-settings' ); ?>">Configuración</a>.</p>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }

    public function render_courses() {
        $selected_id = isset( $_GET['edit_course'] ) ? intval( $_GET['edit_course'] ) : 0;
        $current_cfg = array();

        // Guardar configuración del curso si se envió el formulario
        if ( isset( $_POST['sence_rce_save_course'] ) && check_admin_referer( 'sence_rce_course_nonce' ) ) {
            $course_id = intval( $_POST['wp_course_id'] );
            $data = array(
                'wp_course_id'           => $course_id,
                'wp_site_url'            => home_url(),
                'nombre_curso'           => get_the_title( $course_id ),
                'codigo_sence'           => sanitize_text_field( $_POST['codigo_sence'] ?? '' ),
                'codigo_curso'           => sanitize_text_field( $_POST['codigo_curso'] ?? '' ),
                'linea_capacitacion'     => intval( $_POST['linea_capacitacion'] ?? 3 ),
                'asistencia_obligatoria' => ! empty( $_POST['asistencia_obligatoria'] ) ? 1 : 0,
                'solicitar_cierre'       => ! empty( $_POST['solicitar_cierre'] ) ? 1 : 0,
                'fecha_inicio'           => sanitize_text_field( $_POST['fecha_inicio'] ?? '' ),
                'fecha_termino'          => sanitize_text_field( $_POST['fecha_termino'] ?? '' ),
            );

            delete_transient( 'sence_cfg_' . $course_id );
            $res = $this->api->upsert_course( $data );
            if ( ! is_wp_error( $res ) ) {
                echo '<div class="notice notice-success is-dismissible"><p>Configuración del curso guardada y sincronizada con el backend central.</p></div>';
                if ( ! empty( $res['course'] ) && is_array( $res['course'] ) ) {
                    $current_cfg = $res['course'];
                }
            } else {
                echo '<div class="notice notice-error is-dismissible"><p>Error al guardar en el servidor: ' . esc_html( $res->get_error_message() ) . '</p></div>';
            }
        }

        // Obtener cursos de Tutor LMS o CPT 'courses'
        $cpt = function_exists( 'tutor' ) ? tutor()->course_post_type : 'courses';
        $courses = get_posts( array(
            'post_type'      => array( $cpt, 'course' ),
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'orderby'        => 'title',
            'order'          => 'ASC'
        ) );

        if ( $selected_id && empty( $current_cfg ) ) {
            $current_cfg = $this->api->get_course_config( $selected_id );
        }
        ?>
        <div class="wrap sence-rce-wrap">
            <h1>Configuración SENCE por Curso</h1>
            <div class="sence-rce-two-col">
                <div class="sence-rce-card">
                    <h3>Cursos en tu Plataforma (<?php echo count( $courses ); ?>)</h3>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th>Curso</th>
                                <th>Acción</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( $courses as $c ) : ?>
                            <tr>
                                <td><strong><?php echo esc_html( $c->post_title ); ?></strong><br><small>ID: <?php echo $c->ID; ?></small></td>
                                <td><a href="<?php echo admin_url( 'admin.php?page=sence-rce-courses&edit_course=' . $c->ID ); ?>" class="button button-small">Configurar SENCE</a></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ( $selected_id ) : ?>
                <div class="sence-rce-card">
                    <h3>Configurar: <?php echo esc_html( get_the_title( $selected_id ) ); ?></h3>
                    <form method="POST" action="">
                        <?php wp_nonce_field( 'sence_rce_course_nonce' ); ?>
                        <input type="hidden" name="sence_rce_save_course" value="1">
                        <input type="hidden" name="wp_course_id" value="<?php echo $selected_id; ?>">

                        <table class="form-table">
                            <tr>
                                <th>Línea de Capacitación</th>
                                <td>
                                    <select name="linea_capacitacion">
                                        <option value="3" <?php selected( $current_cfg['linea_capacitacion'] ?? 3, 3 ); ?>>Impulsa Personas (Línea 3 - Franquicia Tributaria)</option>
                                        <option value="1" <?php selected( $current_cfg['linea_capacitacion'] ?? 3, 1 ); ?>>Programas Sociales / Becas Laborales (Línea 1)</option>
                                        <option value="6" <?php selected( $current_cfg['linea_capacitacion'] ?? 3, 6 ); ?>>FPT e-Learning (Línea 6)</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th>Código SENCE (CodSence)</th>
                                <td>
                                    <input type="text" name="codigo_sence" value="<?php echo esc_attr( $current_cfg['codigo_sence'] ?? '' ); ?>" class="regular-text" maxlength="10">
                                    <p class="description">Código de 10 dígitos otorgado por SENCE. (Dejar en blanco para Línea 1).</p>
                                </td>
                            </tr>
                            <tr>
                                <th>Código Curso / ID Acción</th>
                                <td>
                                    <input type="text" name="codigo_curso" value="<?php echo esc_attr( $current_cfg['codigo_curso'] ?? '' ); ?>" class="regular-text">
                                    <p class="description">Identificador de la acción comunicada a SENCE (mínimo 7 caracteres).</p>
                                </td>
                            </tr>
                            <tr>
                                <th>Fecha de Inicio</th>
                                <td>
                                    <input type="date" name="fecha_inicio" value="<?php echo esc_attr( $current_cfg['fecha_inicio'] ?? '' ); ?>">
                                    <p class="description">Desde esta fecha los alumnos podrán registrar asistencia. Vacío = sin restricción.</p>
                                </td>
                            </tr>
                            <tr>
                                <th>Fecha de Término</th>
                                <td>
                                    <input type="date" name="fecha_termino" value="<?php echo esc_attr( $current_cfg['fecha_termino'] ?? '' ); ?>">
                                    <p class="description">Hasta esta fecha (inclusive). Después no se podrá registrar asistencia. Vacío = sin restricción.</p>
                                </td>
                            </tr>
                            <tr>
                                <th>Asistencia Obligatoria</th>
                                <td>
                                    <input type="hidden" name="asistencia_obligatoria" value="0">
                                    <label><input type="checkbox" name="asistencia_obligatoria" value="1" <?php checked( ! empty( $current_cfg['asistencia_obligatoria'] ), true ); ?>> Bloquear lecciones hasta iniciar asistencia SENCE</label>
                                </td>
                            </tr>
                            <tr>
                                <th>Solicitar Cierre de Sesión</th>
                                <td>
                                    <input type="hidden" name="solicitar_cierre" value="0">
                                    <label><input type="checkbox" name="solicitar_cierre" value="1" <?php checked( ! empty( $current_cfg['solicitar_cierre'] ), true ); ?>> Exigir al alumno registrar cierre antes de retirarse</label>
                                </td>
                            </tr>
                        </table>
                        <?php submit_button( 'Guardar y Sincronizar con la Nube' ); ?>
                    </form>
                </div>
                <?php else : ?>
                <div class="sence-rce-card">
                    <h3>Selecciona un Curso</h3>
                    <p>Haz clic en "Configurar SENCE" en cualquiera de los cursos para enlazar sus códigos gubernamentales.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    public function render_sessions() {
        // Procesar vaciado/reinicio del libro de asistencia si fue solicitado por el administrador
        if ( isset( $_GET['action'] ) && $_GET['action'] === 'reset_sessions' ) {
            check_admin_referer( 'sence_reset_sessions' );
            $reset_res = $this->api->reset_sessions();
            if ( ! is_wp_error( $reset_res ) && ! empty( $reset_res['success'] ) ) {
                echo '<div class="notice notice-success is-dismissible"><p>✅ El libro digital ha sido reiniciado. Todos los registros de asistencia fueron eliminados.</p></div>';
            } else {
                $err_msg = is_wp_error( $reset_res ) ? $reset_res->get_error_message() : ( $reset_res['error'] ?? 'Error desconocido' );
                echo '<div class="notice notice-error is-dismissible"><p>No se pudieron eliminar los registros: ' . esc_html( $err_msg ) . '</p></div>';
            }
        }

        // Procesar cierre manual de sesión si fue solicitado por el administrador
        if ( isset( $_GET['action'] ) && $_GET['action'] === 'close_session' && ! empty( $_GET['session_id'] ) ) {
            $target_sid = intval( $_GET['session_id'] );
            check_admin_referer( 'sence_close_session_' . $target_sid );
            $close_res = $this->api->close_session_manual( $target_sid );
            if ( ! is_wp_error( $close_res ) && ! empty( $close_res['success'] ) ) {
                echo '<div class="notice notice-success is-dismissible"><p>Sesión #' . $target_sid . ' cerrada y conciliada correctamente.</p></div>';
            } else {
                $err_msg = is_wp_error( $close_res ) ? $close_res->get_error_message() : ( $close_res['error'] ?? 'Error desconocido' );
                echo '<div class="notice notice-error is-dismissible"><p>No se pudo cerrar la sesión: ' . esc_html( $err_msg ) . '</p></div>';
            }
        }

        $page = isset( $_GET['paged'] ) ? max( 1, intval( $_GET['paged'] ) ) : 1;
        $limit = 25;
        $offset = ( $page - 1 ) * $limit;

        $response = $this->api->get_sessions( array( 'limit' => $limit, 'offset' => $offset ) );
        $sessions = $response['sessions'] ?? array();
        $total    = $response['total'] ?? 0;
        $csv_url  = $this->api->export_csv_url();
        $reset_url = wp_nonce_url( admin_url( 'admin.php?page=sence-rce-sessions&action=reset_sessions' ), 'sence_reset_sessions' );
        ?>
        <div class="wrap sence-rce-wrap">
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <h1>Registro de Asistencias (Libro Digital SENCE)</h1>
                <div style="display:flex; gap:10px;">
                    <a href="<?php echo esc_url( $csv_url ); ?>" class="button button-primary" target="_blank">📥 Exportar CSV para SENCE</a>
                    <a href="<?php echo esc_url( $reset_url ); ?>" class="button button-secondary" style="color:#b32d2e; border-color:#b32d2e;" onclick="return confirm('⚠️ ¿Estás seguro de que deseas eliminar permanentemente todos los registros de asistencia del libro digital? Esta acción no se puede deshacer.');">🗑️ Reiniciar Libro de Asistencias</a>
                </div>
            </div>

            <div class="sence-rce-card" style="margin-top:20px;">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>RUN Alumno</th>
                            <th>Curso</th>
                            <th>Inicio Sesión</th>
                            <th>Cierre Sesión</th>
                            <th>Duración</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ( ! empty( $sessions ) ) : foreach ( $sessions as $s ) : ?>
                        <tr>
                            <td>#<?php echo esc_html( $s['session_id'] ); ?></td>
                            <td><strong><?php echo esc_html( $s['run_alumno'] ); ?></strong></td>
                            <td><?php echo esc_html( $s['nombre_curso'] ?: 'ID: ' . $s['course_id'] ); ?></td>
                            <td><?php echo esc_html( $this->format_chile_datetime( $s['session_opened_at'] ?? '' ) ); ?></td>
                            <td><?php echo esc_html( $this->format_chile_datetime( $s['session_closed_at'] ?? '' ) ); ?></td>
                            <td><?php echo esc_html( $s['tiempo_sesion_formateado'] ?? '-' ); ?></td>
                            <td>
                                <?php if ( $s['is_active'] && ! $s['session_closed_at'] ) : ?>
                                    <span class="sence-badge success">En Curso</span>
                                    <?php
                                    $close_url = wp_nonce_url(
                                        admin_url( 'admin.php?page=sence-rce-sessions&action=close_session&session_id=' . $s['session_id'] ),
                                        'sence_close_session_' . $s['session_id']
                                    );
                                    ?>
                                    <br><a href="<?php echo esc_url( $close_url ); ?>" class="button button-small" style="margin-top:6px; font-size:11px;" onclick="return confirm('¿Deseas cerrar manualmente esta sesión de asistencia?');">Cerrar Sesión</a>
                                <?php elseif ( $s['error_code'] ) : ?>
                                    <span class="sence-badge error">Error <?php echo esc_html( $s['error_code'] ); ?></span>
                                <?php else : ?>
                                    <span class="sence-badge secondary">Cerrada</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; else : ?>
                        <tr><td colspan="7">No se encontraron registros de asistencia aún.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }

    public function render_settings() {
        ?>
        <div class="wrap sence-rce-wrap">
            <h1>Configuración SENCE RCE Cloud</h1>
            <form method="POST" action="options.php">
                <?php
                settings_fields( 'sence_rce_cloud_options_group' );
                do_settings_sections( 'sence-rce-settings' );
                submit_button( 'Guardar Configuración' );
                ?>
            </form>

            <div class="sence-rce-card" style="margin-top:20px;">
                <h3>Probar Conectividad</h3>
                <p>Verifica la comunicación en tiempo real con el servidor backend de Railway:</p>
                <button type="button" id="btn-test-connection" class="button button-secondary">⚡ Probar Conexión Ahora</button>
                <span id="test-connection-result" style="margin-left:15px; font-weight:bold;"></span>
            </div>
        </div>
        <?php
    }

}
